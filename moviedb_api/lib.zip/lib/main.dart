import 'package:flutter/material.dart';
import 'package:moviedb_api/cache_module/cache_app.dart';

void main() {
  runApp(cacheAppWithProvider());
}



